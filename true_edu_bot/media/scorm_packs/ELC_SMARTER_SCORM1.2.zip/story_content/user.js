function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6I59NXPYs8j":
        Script1();
        break;
      case "5f8FV3PCy8n":
        Script2();
        break;
      case "5orO95guWVk":
        Script3();
        break;
      case "6Z6N2lSnSDk":
        Script4();
        break;
      case "6VKvxUHQEuZ":
        Script5();
        break;
      case "6SaoDerKe3Z":
        Script6();
        break;
      case "6JSwiRh9ri4":
        Script7();
        break;
      case "6XLPTJHdUFP":
        Script8();
        break;
      case "5q48dHwe3Up":
        Script9();
        break;
      case "5nWnbbVvuR7":
        Script10();
        break;
      case "5vLAiHPGQOE":
        Script11();
        break;
      case "6TC4Y71YZ3H":
        Script12();
        break;
      case "5aEdUV9Uwv9":
        Script13();
        break;
      case "6O1c8vgYDCC":
        Script14();
        break;
      case "6GjEQmQLEEz":
        Script15();
        break;
      case "64zDeCDdL22":
        Script16();
        break;
      case "60L0FzdctkF":
        Script17();
        break;
      case "6lMqYIIuUVz":
        Script18();
        break;
      case "6LuCqyzdhlI":
        Script19();
        break;
      case "5WtU1F8v5sq":
        Script20();
        break;
      case "5XyczbfAMMW":
        Script21();
        break;
      case "656ou7XtUev":
        Script22();
        break;
      case "5if7k16QOvz":
        Script23();
        break;
      case "5X7HBULmO9W":
        Script24();
        break;
      case "6WEJWztVxAd":
        Script25();
        break;
      case "6ECvMPL726X":
        Script26();
        break;
      case "6XpI7IKY9Fv":
        Script27();
        break;
      case "6pCr8gWWouU":
        Script28();
        break;
      case "6HQh3SBP07c":
        Script29();
        break;
      case "5yqjC1vyn9Y":
        Script30();
        break;
      case "5urF2ETYpaE":
        Script31();
        break;
      case "6MednL2mVXc":
        Script32();
        break;
      case "6TIh8WJ2ZCT":
        Script33();
        break;
      case "5lvoKcBE4Hs":
        Script34();
        break;
      case "5baUOrjByLb":
        Script35();
        break;
      case "6aCqkp8phFI":
        Script36();
        break;
      case "6PLGkgnNSR6":
        Script37();
        break;
      case "60WAv6a3s8M":
        Script38();
        break;
      case "6D8z2wNtdoL":
        Script39();
        break;
      case "6IpGDdKDOaV":
        Script40();
        break;
      case "6KGPaxrsS4R":
        Script41();
        break;
      case "5sS3V2DM0Mf":
        Script42();
        break;
      case "6MPJ5ow98Fv":
        Script43();
        break;
      case "6bJD6lv7V1K":
        Script44();
        break;
      case "6fVpvncIYu3":
        Script45();
        break;
      case "5WBxUqB9EPG":
        Script46();
        break;
      case "5wUtLeRWKTP":
        Script47();
        break;
      case "5zISIRORYMa":
        Script48();
        break;
      case "6IQlK2Ku9SW":
        Script49();
        break;
      case "5hm8yRqNROF":
        Script50();
        break;
      case "5Usj161DjBm":
        Script51();
        break;
      case "6bWmxfI1uRB":
        Script52();
        break;
      case "6OTUnbWqRA0":
        Script53();
        break;
      case "6lWxY863kOy":
        Script54();
        break;
      case "6FA3WvXnYW9":
        Script55();
        break;
      case "66inp7UPFlg":
        Script56();
        break;
      case "6FmoFdutJHK":
        Script57();
        break;
      case "65XY2Kzk602":
        Script58();
        break;
      case "6hFZ6qU4zia":
        Script59();
        break;
      case "5tmsx3FyGVK":
        Script60();
        break;
      case "6cnJnWuHP65":
        Script61();
        break;
      case "6HTX2FWug2v":
        Script62();
        break;
      case "69vIwJiCMip":
        Script63();
        break;
      case "66cGGYNAKN1":
        Script64();
        break;
      case "5tB9Kdpq8M0":
        Script65();
        break;
      case "5clsSOlKnS8":
        Script66();
        break;
      case "6oWGr5dUkER":
        Script67();
        break;
      case "5ePwHDgDD0q":
        Script68();
        break;
      case "5q1wcN7xy41":
        Script69();
        break;
      case "5hfDeH7K9AT":
        Script70();
        break;
      case "5q9TLcTehYL":
        Script71();
        break;
      case "6DDWC43Bslh":
        Script72();
        break;
  }
}

function Script1()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script2()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script3()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script4()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script5()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script6()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script7()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script8()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script9()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script10()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script11()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script12()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script13()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script14()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script15()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script16()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script17()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script18()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script19()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script20()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script21()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script22()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script23()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script24()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script25()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script26()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script27()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script28()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script29()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script30()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script31()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script32()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script33()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script34()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script35()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script36()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script37()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script38()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script39()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script40()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script41()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script42()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script43()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script44()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script45()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script46()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script47()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script48()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script49()
{
  var newWin=window.open("goal.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script50()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script51()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script52()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script53()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script54()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script55()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script56()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script57()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script58()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script59()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script60()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script61()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script62()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script63()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script64()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script65()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script66()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script67()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script68()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script69()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script70()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script71()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

function Script72()
{
  var newWin=window.open("focus.html", "_blank", "status=0,scrollbars=0,width=900,height=1131");
}

